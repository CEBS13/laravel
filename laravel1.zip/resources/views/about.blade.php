<!doctype html>
<html lang="en">
    <head>
    <meta charset="UTF-8"/>
    <title>Document</title>
    </head>
    <body>
        <h1> Hola {{$first}} {{$last}} </h1>
        
    <p>
    Auctor eu augue!
    </p>
    <p>
    In tellus integer.
    </p>
    <p>
    Sodales neque sodales?
    </p>

    </body>
    </html>
 
