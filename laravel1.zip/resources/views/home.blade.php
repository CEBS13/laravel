<!doctype html>
<html lang="en">
    <head>
    <meta charset="UTF-8"/>

    <title>Home</title>

   <link rel="stylesheet" href="css/main" type="text/css" />
             

    </head>


    <header id="banner" class="body">
        <h1> <a href="#"> Smashing HTMl5! <strong> HTML5 in the year <del> 2022</del> <ins> 2009</ins></strong>

            <nav> <ul>
                <li class="active"><a href="#">home</a></li>
                <li><a href="#">portfolio</a></li>
                <li><a href="#">blog</a></li>
                <li><a href="#"> contact</a></li>
            </ul> </nav>

    </header> <!-- banner  --> 
    
    <body id="index" class="home">


    </body>  


    </html>
